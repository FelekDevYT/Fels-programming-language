package net.felsstudio.fels.annotations

annotation class INFO {
    companion object {
        const val info: Int = 1
    }
}
