package net.felsstudio.fels.lib;

/**
 *
 * @author felek
 */
public interface Function {

    Value execute(Value... args);
}
