package net.felsstudio.fels.Modules

interface Module {
    fun init()
}
