package net.felsstudio.fels.exceptions

class PatternMatchingException : RuntimeException {
    constructor()

    constructor(message: String?) : super(message)
}
