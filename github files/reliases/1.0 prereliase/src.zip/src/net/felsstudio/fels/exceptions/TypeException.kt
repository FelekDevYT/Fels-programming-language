package net.felsstudio.fels.exceptions

class TypeException(message: String?) : RuntimeException(message)
