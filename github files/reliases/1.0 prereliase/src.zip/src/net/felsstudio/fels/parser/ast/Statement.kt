package net.felsstudio.fels.parser.ast

/**
 *
 * @author felek
 */
interface Statement : Node {
    fun execute()
}
