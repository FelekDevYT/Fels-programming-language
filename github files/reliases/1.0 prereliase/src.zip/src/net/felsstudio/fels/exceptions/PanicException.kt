package net.felsstudio.fels.exceptions

class PanicException(message: String) : RuntimeException("Panic: $message")
