package net.felsstudio.fels.exceptions

class StoppedException : RuntimeException()