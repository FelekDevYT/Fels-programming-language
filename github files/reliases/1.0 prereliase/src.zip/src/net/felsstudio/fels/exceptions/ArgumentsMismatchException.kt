package net.felsstudio.fels.exceptions

class ArgumentsMismatchException : RuntimeException {
    constructor()

    constructor(message: String?) : super(message)
}
